# prime_single_channels.py
# Aspirate & dispense each base color into its own well (no mixing):
#   - Red (A)   -> C1
#   - Green (B) -> C2
#   - Blue (C)  -> C3
#
# Reservoir mapping (same as your reference):
#   A (red)   -> reservoir['B3']
#   B (green) -> reservoir['A4']
#   C (blue)  -> reservoir['A3']

from opentrons import protocol_api

metadata = {
    'protocolName': 'Prime Single Channels into Separate Wells (250 µL each)',
    'author': 'you',
    'description': 'Simple protocol for learning OT-2 operation',
    'apiLevel': '2.13'
}

TOTAL_VOL_UL = 300                # volume to dispense per well
DEST_WELLS   = {'A': 'F1', 'B': 'F2', 'C': 'F3'}  # red->C1, green->C2, blue->C3

def run(protocol: protocol_api.ProtocolContext):

    # --- 1) Labware ---
    plate = protocol.load_labware('corning_96_wellplate_360ul_flat', '1')
    tiprack = protocol.load_labware('opentrons_96_tiprack_300ul', '11')
    reservoir = protocol.load_labware('opentrons_10_tuberack_falcon_4x50ml_6x15ml_conical', '3')

    # --- 2) Pipette ---
    p300 = protocol.load_instrument('p300_single_gen2', 'left', tip_racks=[tiprack])

    # --- 3) Reservoir mapping (same as your reference) ---
    chan_A_src = reservoir['B3']  # A (red)
    chan_B_src = reservoir['A4']  # B (green)
    chan_C_src = reservoir['A3']  # C (blue)

    # --- 4) Dispense each base color into its dedicated well ---

    # Red (A) -> C1
    p300.pick_up_tip()
    p300.aspirate(TOTAL_VOL_UL, chan_A_src)
    p300.dispense(TOTAL_VOL_UL, plate[DEST_WELLS['A']])
    p300.drop_tip()
    protocol.comment(f"Dispensed {TOTAL_VOL_UL} µL RED (A) into {DEST_WELLS['A']}")

    # Green (B) -> C2
    p300.pick_up_tip()
    p300.aspirate(TOTAL_VOL_UL, chan_B_src)
    p300.dispense(TOTAL_VOL_UL, plate[DEST_WELLS['B']])
    p300.drop_tip()
    protocol.comment(f"Dispensed {TOTAL_VOL_UL} µL GREEN (B) into {DEST_WELLS['B']}")

    # Blue (C) -> C3
    p300.pick_up_tip()
    p300.aspirate(TOTAL_VOL_UL, chan_C_src)
    p300.dispense(TOTAL_VOL_UL, plate[DEST_WELLS['C']])
    p300.drop_tip()
    protocol.comment(f"Dispensed {TOTAL_VOL_UL} µL BLUE (C) into {DEST_WELLS['C']}")

    protocol.comment("✅ Primed base colors into separate wells (C1: red, C2: green, C3: blue).")
